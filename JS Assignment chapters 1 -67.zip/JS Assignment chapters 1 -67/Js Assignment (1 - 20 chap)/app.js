// CHAPTER NO 1

//  TASK #1

// alert("Welcome To Solex.pk");

//  TASK #2

// alert("Error! Please Enter a valid password.");

//  TASK #3

// alert("Welcome to JS Land... \n Happy Coding!");

//  TASK #4
// alert("Welcome to JS Land...")
// alert("  Happy Coding!");

//  TASK #5

// console.log("Hello... I can run JS through my web browser console");

// *******************

// chapter NO 2
// TASK #1

// var a="UserName:";
// var b=" " + "M_Ahsan";
// var c=a+b;
// alert(c);

// task #2

// var my= "Ahsan";
// var Name="Asif";
// var c=my+" "+Name;
// alert(c)

// task #3

// var a="Hello";
// var b="World";
// var c=a+b;
// alert(c);

// task#4

// var a = "Ahsan";
// var b = "Asif";
// var c = a+ " " +b;
// alert(c)

// var d = 20;
// var e = "years Old";
// var f = d+" "+e;
// alert(f)

// var g = "Certified Mobile";
// var h = "Application Development";
// var i= g + " " + h;
// alert(i)

// Task #5

// alert("PIZZA \nPIZZ \nPIZ \nPI \nP")

// Task #6

// var a="E-mail:";
// var b="muhammadahsan178@gmail.com"
// var c= a + " " + b;
// alert(c)

// task#7

// var book="A Smarter way to learn Javascript";
// alert ("I am trying to learn from the book" + " " + book)

// task#8

// document.write("yah! I can write HTML content through Javascript.");

// task#9

// var a="▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
// alert(a)
// console.log(a)

// *******************
// CHAPTER #3

// TASK#1

// var age= 20;
// var years=" Years old";
// var c=age+years;
// alert("I Am"+" "+ c)

//       Task#2
// var n= 14;
// alert("You have visited this site" +" "+ n + " " + "Times");

//     Task#3
// var a="My Birth Year is";
// var b=1990;
// var c= a + " " + b +"\n"+ "Data type Of my declared variable is number" ;
// alert(c)

//        // Task#4
//        var Name="Mr.Ahsan";
//        var title="XYZ Clothing Store";
//        var Quantity=" 5 T-Shirt(s)";
//        var a= Name +" "+"ordered"+ Quantity+" on" +" " + title;
//       document.write(a);

// *******************
// CHAPTER #4

// TASK#1

// var Name = "Mr.Ahsan";
// var title = "XYZ Clothing Store";
// var Quantity = " 5 T-Shirt(s)";
// var a= Name +" "+"ordered"+ Quantity+" on" +" " + title;
// alert(a)

// Task#2

//     legal Names

//        var a= "A variable name can't contain any spaces,";
// var b= "A variable name can contain only letters, numbers, dollar signs, and underscores";
// var c= a + " " + b;
// document.write(c);

// il-leagal name

// Use spaces, mathemathematical opertors e.g + or - or * or /, logical operators e.g. && or ||, start variable name with a number.

//      task#3

//  document.write(" a) A heading stating Rules for naming JS variables" + "<br>");
// document.write(" b) Variable names can only contain" + "," + " " + " numbers," + " " + "$," + " " + "_." + " " + "For example $my_1stVariable" + "<br>");
// document.write("c) Variables must begin with a letter, $, _." + " " + "For example $name, _name or name" + "<br>");
// document.write("d) Variable names are case sensitive." + "<br>");
// document.write("e) Variable names should not be JS keywords." + "<br>");

// *******************
// CHAPTER #5

// TASK#1

// var a= 5;
// var b= 6;
// var c= a +b;
// document.write("Sum of 5 and 6 is"+ " "+c);

//     TASK#2
//    (multiplication process)
// var a= 5;
// var b= 6;
// var c= a*b;
// document.write(c);

//    (division Process)
// var a= 30;
// var b= 6;
// var c= a/b;
// document.write(c);

//   modulus Process

// var a= 49;
// var b= 7;
// var c= a%b;
// document.write(c);

// Task #3

//  var a= 1;
//  var b=5;
//  var c=a+b;
//  document.write(" value after increment is:"+  c +"<br>"  );
//  var d=c+7;
//  document.write(" value after addition is:" + d +"<br>" );
// var e=d-1;
// document.write(" value after decrement is:"+ e +"<br>" );
// var f=e/3;
// document.write(" The remainder is:"+ f +"<br>" );

// Task#4
// var Quantity=5;
// var price=600;
// var c=price*Quantity;
// document.write("Total cost to buy 5 tickets to a movie is" +" " + c +"PKR" );

//       TASK#5

// for(var i=1; i<=10; i++){
//        document.write("4" + "x" + i + "=" + 4*i + "<br>" )
// }

// Task#6

// var c= 25;
// var f= 70;

// var e=(c*9/5)+32;
// document.write( c + "<sup> 0 </sup>" + "C"+ " " + "is"+" "+ e + "<sup> 0 </sup>" + "F" +"<br>")

// var d=(f-32)*5/9;
// document.write( f + "<sup> 0 </sup>" + "F"+ " " + "is"+" "+ d + "<sup> 0 </sup>" + "C" +"<br>")

// Task#7

// var item1 = 650;
// var qtyItem1 = 3;
// var item2 = 100;
// var qtyItem2 = 7;
// var shippingchrge = 100;
// var totalcharges = (item1 * qtyItem1) + (item2 * qtyItem2) + shippingchrge;
// document.write(" Price of item 1 is 650" + "<br>" + "Quantity of item 1 is 3" + "<br>" + "Price of item 2 is 100" + "<br>" + "Quantity of item 2 is 7"  + "<br>" + "Shipping charges 100"  + "<br>" +"Total cost of your order is"+" "+ totalcharges)

//    Task#8

// var totalMarks=980;
// var marksObtained=804;
// var percentage= marksObtained/totalMarks*100;
// document.write("Total Marks: 980"+"<br>"+ "Marks Obtained: 804"+"<br>"+"Percentage:"+percentage +"%")

// Task#9

// var Dollar=104.80;
// var SaudiRiyal=28;
// var TotalDollar=10;
// var TotalRiyal=25;
// var TotalRupee=(TotalDollar*Dollar)+(TotalRiyal*SaudiRiyal);
// document.write("Total Currency in PKR:"+ " "+TotalRupee)

// Task#10
// var a=10;
// var add=5;
// var multiply=10;
// var divide=2;
// var Total=a+add*multiply/divide;
// console.log(Total);

//      Task#11

// var currentYear= 2020;
// var birthYear= 1999;
// var age=currentYear-birthYear;
// document.write("They are Either" + " "+ age + "Years old")

//    Task#12

// var circleRadius=20;
// var circumference=3.142;
// var a= circleRadius*2*circumference;
// var b= circleRadius*circumference*20;
// document.write("Radius Of A Circle: 20" + "<br>")
// document.write("Circumference is:"+a+"<br>")
// document.write("The Area is:"+b)

//  Task#13

// document.write("Favourite SnacK:"+ " "+ "Chips" + "<br>")
// document.write("Current Age:"+ " "+ "20 "  + "<br>")
// document.write("Estimated Maximum Age:"+ " "+ "65"  + "<br>")
// document.write("Amount Of Snack Per Day:"+ " "+ "3"  + "<br>")
// document.write("You Will Need 150 Chips To last you untill the ripe old age of"+ " "+ "65")

// *******************
// CHAPTER #6-9

// TASK#1

// var a=10;
// var b=a + ++a + a++ - --a - a--;
// document.write("Now the value of a is:" + " " + b)

// TASK#2
// var a=2;
// var b=1;
// var result = --a - --b + ++b + b-- ;
// console.log(result);

//       Task#3
// var a= prompt("Enter Your Name","Your Name is");
// var b= "Hello"+ " " + a;
// alert(b)

//     Task#5

// var e= +prompt("enter a number",5)
// for( var i=1; i<=10; i++) {
// document.write( e + "x" + i + "=" +  e*i +"<br>");
// }

//      Task#6

// var subject1 = prompt("Enter Your Subject")
// var subject2 = prompt("Enter Your Subject")
// var subject3 = prompt("Enter Your Subject")

// var totalMarks = 100;

// var subj1Obtained = prompt("Enter" + " " + subject1 + " " + "Marks")
// var subj2Obtained = prompt("Enter" + " " + subject2 + " " + "Marks")
// var subj3Obtained = prompt("Enter" + " " + subject3 + " " + "Marks")

// var percentage1 = subj1Obtained / totalMarks * 100
// var percentage2 = subj2Obtained / totalMarks * 100
// var percentage3 = subj3Obtained / totalMarks * 100

// document.write(percentage1 + "%" + "<br>")
// document.write(percentage2 + "%" + "<br>")
// document.write(percentage3 + "%" + "<br>")

// *******************
// CHAPTER #9-11

// TASK#1

// var city = prompt("Enter Your City Name");
// if(city === "karachi"){
//        alert("Welcome To The City Of Lights");
// }

// else {
//        alert("Welcome Back!");
// }

// Task#2

// var gender = prompt("Enter Your Gender");
// if(gender === "male"){
//        alert ("Good Morning Sir");
// }
// else(gender === "female"){
//        alert ("Good Morning Ma'am");
// }
// else(gender === "other"){
//        alert ("You Didn't write correct Gender");
// }

//       Task#3

// var Signal = prompt("Enter The Signal Color","Red Yellow Green");
// if (Signal === "red") {
//        alert("Must Stop");
// }

// else if (Signal === "yellow") {
//        alert("Ready to move");
// }

// else if (Signal === "green") {
//        alert("Move now");
// }

//       Task#4

// var petrol = prompt(" input remaining fuel in car");
// if ( petrol > 0.25) {
//        alert("You Have sufficient Fuel");
// }
// else if ( petrol < 0.25) {
//        alert("Please refill the fuel in your car")
// }

//    Task#5

// var a = 4;
// if (++a === 5) {
//        alert("given condition for variable a is true");
// }

// var b = 82;
// if (b++ === 83) {
//        alert("given condition for variable b is not true");
// }

// var c = 12;
// if (c++ === 13){
// alert("condition 1 is not true");
// }
// if (c === 13){
// alert("condition 2 is true");
// }
// if (++c < 14){
// alert("condition 3 is  not true");
// }
// if(c === 14){
// alert("condition 4 is true");
// }

// var materialCost = 20000;
// var laborCost = 2000;
// var totalCost = materialCost + laborCost;
// if (totalCost === laborCost + materialCost){
// alert("The cost equals");
// }

// if (true) {
//        alert("True");
// }
// if (false) {
//        alert("False");
// }

//    Task#6

// var marks = +prompt("Enter Your 3 subjects Marks Obtained");
// var totalMarks = +prompt("Enter Your Total Marks");

// var percentage = marks/totalMarks*100

//  if(percentage > 80){
//     alert("Total Marks:" + totalMarks  + "\n" + "Marks Obtained : " + marks + "\n" +"Percentage: " +  percentage + "%"  + "\n" + "Grade: A-one " + "\n" + "Remarks : Excellent");
//  }
//  if(Percentage => 70 && Percentage < 80){
//   alert("Total Marks: " + totalMarks  + "\n" + "Marks Obtained : " + marks+ "\n" +"Percentage: " + percentage + "%"  + "\n" + "Grade: A " + "\n" + "Remarks : Good")
// }
// if(Percentage > 60 && Percentage < 70){
//     alert("Total Marks:  " + totalMarks + "\n" + "Marks Obtained : " + marks + "\n" +"Percentage: " + percentage + "%"   + "\n" + "Grade: B " + "\n" + "Remarks : You Need To  Improve")
// }
// else if(Percentage > 0 && Percentage < 60){
//     alert("totalMarks : " + totalMarks + "\n" + "Marks Obtained : " + marks + "\n" +"Percentage: " +   percentage + "%"   + "\n" +  "Grade: Fail " + "\n" + "Remarks : Sorry")
// }

//  Task#7

// var number = +prompt("Enter Your Number");
// if(number===2){
//     alert("Bingo! Correct Answer")
// }
// else if (number==1,3){
//     alert("Close enough to the correct answer")
// }

// Task#8

// var Number= +prompt("Enter Your Number");
// var a= Number/3;
// if ( Number/3){
//     alert("Answer is" + " " + Number)
// }
// else if (Number/3==0){
//     alert("You Have Entered A Even Number")
// }

// Task#9

// var Number= +prompt("Enter Your Number");
// if ( Number%2 == 0){
//     alert("even" + " " + Numbers  )
// }
// else if (Number%2!== 0){
//     alert("odd" + " " + Numbers)
// }

// Task#10

// var temperature= +prompt("Enter the Temperature");
// if( temperature >40 &&  temperature<50){
//     alert("It's too hot outside")
// }
// if( temperature >30 &&  temperature<40){
//     alert("The Weather today is Normal.")
// }
// if( temperature >20 &&  temperature<30){
//     alert("Today’s Weather is cool.")
// }
// if( temperature >10 &&  temperature<20){
//     alert("OMG! Today’s weather is so Cool.")
// }

// *******************
// CHAPTER #12-13

// TASK#1

// var userInput= prompt("Enter Your input");
// if(userInput >= 65 && userInput <= 90) {
//     document.write("It's Capital Letter");
// }
// if(userInput >= 90 && userInput <= 130) {
//     document.write("It's Small Letter");
// }

//  Task#2

// var age= +prompt("Enter Your Age");
// var gender = +prompt ("Enter Your Gender");
// if( age > 18 || age < 65 && gender == "male" ){
//     alert("You Are selected")
// }
// else{
//     alert("You are not eligible")
// }

//  Task#4

//  var i = prompt("Enter Your City Name");
// var i = ["karachi", "lahore", "multan", "kashmir", "Islamabad"];
// for (var i = o; i < cities.length; i++)
//     if (cities [i]=== "a,e,i,o,u"){
//         alert (i +"true")
//     }
//     else{
//         alert(i + "false")
//     }

// Task#5

// var a = prompt("Enter Your password");
// var a = "Hello";
// if(a == "Hello"){
// alert("Correct")
// }
// else if (a!= "World"){
// alert("incorrect")
// }

// Task#6

// var hour = +prompt("Enter The time");
// if (hour < 18) {
//     alert("Good day")
// }

// else if ( hour > 19) {
//     alert("Good evening")
// }

// Task#7

// var hour = prompt("Enter the time");
// if( hour >=0000 && hour <1200 ){
//     alert("Good Morning")
// }
// else if( hour >=1200 && hour <1700){
//     alert("Good Afternoon")
// }
// else if (hour >=1700 && hour <2100){
// alert("Good Evening")
// }
// else if(hour >=2100 && hour <2359){
//     alert("Good Night")
// }

//   CHAPTER 14-16 (ARRAY)

// QUESTION # 1

// var a = {}

// QUESTION # 2

// var a = []

// QUESTION # 3

//  var arr = [];
// var arr = ["Hello","World"];

// QUESTION # 4

// let arr = new Array (1, 2, 3, 4, 5);
// console.log(arr);

// QUESTION # 5

// var anyBoxesChecked = [];
// var numeroPerguntas = 5;
// for(var i = 0; i < numeroPerguntas; i++) {
//   anyBoxesChecked.push(false);
// }

// console.log(anyBoxesChecked)


// QUESTION # 7

// document.write("<h1>Qualifications</h1> <br>");
// eduqua = ["SSC", "HSC", "BCS", "BS", "BCOM", "MS", "M.phil", "Phd"];
// document.write("1)" + eduqua[0] + "<br><br>");
// document.write("2)" + eduqua[1] + "<br><br>");
// document.write("3)" + eduqua[2] + "<br><br>");
// document.write("4)" + eduqua[3] + "<br><br>");
// document.write("5)" + eduqua[4] + "<br><br>");
// document.write("6)" + eduqua[5] + "<br><br>");
// document.write("7)" + eduqua[6] + "<br><br>");
// document.write("8)" + eduqua[7] + "<br><br>");

// QUESTION # 8

// var std = ["Michael","John","Tony"];
// var marks = [320,230,480];
// var totalMarks = 500

// for (let i=0; i<std.length; i++){
//     document.write("Score of " + std[i] + " is " + marks[i] + ". Percentage : " + marks[i]/totalMarks*100 + "%"+ "<br>")
// }

// QUESTION # 9

//  a
//    color=["Pink","Blue","Red"]
// document.write("a "+color+"<br><br>");
//  var a =prompt("Enter color to add in Beginni");
//  color.unshift(a)
//   document.write("a "+color+" <br><br>");

// //b
// color=["Pink","Blue","Red"]
// document.write("b "+color+"<br><br>");
//  var a =prompt("Enter color to add in End")
//   color.push(a)
//  document.write("b "+color+" <br><br><br>");

// //c
// color=["Pink","Blue","Red"]
// document.write("c "+color+"<br><br>");
//  var a =prompt("Enter color to two more add");
//   color.unshift(a)
//  document.write("c "+color+" <br><br>");

// //d
// color= ["Pink", "Blue", "Red"]
// document.write("d "+color+"<br><br>");
//  var a =prompt("Delete the first color array");
//   color.unshift(a)
//  document.write("d "+color+" <br><br>");

//  //e
// color=["Pink","Blue","Red"]
// document.write("e "+color+"<br><br>");
//  var a =prompt("Delete the last color array")
//   color.pop(a)
//   document.write("e "+color+" <br><br>");

// //f
//  color=["Pink","Blue","Red"]
//  var pos=0
//  pos=prompt("Enter index to add")
//   temp=prompt("enter color")
//   color.splice(pos,0,temp)
//    document.write("f "+color)

// QUESTION # 10

// sstd =[320,230,480,120]
//  ostd=[120,230,320,480]
// document.write("Scores of Students: " +sstd [0] + "" +sstd [1] + "" +sstd [2] + "" +sstd [3] + "<b><b><b>")
//  document.write("Ordered Score of Students: " +ostd[0] + "" +ostd [1] + "" +ostd [2] + "" +ostd [3] + "<b><b><b>")

// QUESTION # 11

// var citylists=["Karachi","Lahore","Islamabad","Quetta","Peshawar"];
//  document.write("Cities list: " +citylists+ "<b><b>");
//  var a = citylists.slice(2,4)
//  document.write("Selected cities list: <br>" +a + "<b><b><b>")

// QUESTION # 12

// var arr = ["This" , "is", " my ", "cat"];
// document.write("<h2> Array: <br>" +arr+ "<br></h2>" )
// var str = ["This is my cat"];
//  document.write("<h2><br><br> String: <br>" +str + "</h2>" )

// QUESTION # 13

// var arr = ["Keyboard", "mouse", "printer", "monitor"];
// document.write("Devices <br>" + arr + "<br><br>");
// w = arr.shift(0);
// x = arr.shift(1);
// y = arr.shift(2);
// z = arr.shift(3);
// document.write("Out : <br>" + w + "<br>");
// document.write("Out : <br>" + x + "<br>");
// document.write("Out : <br>" + y + "<br>");
// document.write("Out : <br>" + z + "<br>");

// QUESTION # 14

// var arr = ["Keyboard" , "mouse" , "printer" , "monitor"];
// document.write("Devices <br>" +arr+"<br><br>") 
// w = arr.pop(0);
// x = arr.pop(1); 
// y = arr.pop(2);
// z = arr.pop(3); 
// document.write("Out : <br>" +w+"<br>");
//  document.write("Out : <br>" +x+"<br>");
//  document.write("Out : <br>" +y+"<br>");
//  document.write("Out : <br>" +z+"<br>"); 

// QUESTION # 15

// var arr = ["Apple", "Samsung", " Motorola", "Nokia" , "Sony" , "Haier"] 
// document.write(arr[0] +"<br>")
// document.write(arr[1] +"<br>") 
// document.write(arr[2] +"<br>") 
// document.write(arr[3] +"<br>") 

//   CHAPTER 17-20 (ARRAYS AND LOOP )


// Question # 1

// var TwoDArray = [[],[]];

// Question # 2


// let matrix = [[0, 1, 2, 3],[ 1, 0, 1, 2],[ 2, 1, 0, 1]];
//   alert(matrix[0]+"\n"+matrix[1]+"\n"+matrix[2]);

// Question # 3

// for(var x =1 ; x <=10 ; x++){
//     document.writeln(x+"<br>");
// }

// Question # 4

// var a = +prompt("enter table number");
// var userTime = +prompt("Enter how many time you want to multiply");
// for(b = 1; b<=userTime; b++){
//     c=(a*b);
//     document.writeln(a+ " x " +b+ " = " +c +"<br>");
// }

// Question # 5

// var xyzArr = ["apple", "banana", "mango", "orange", "strawberry"];
// document.writeln("Elements of array are:".bold()+"<br>");
// for( var z = 0; z<xyzArr.length ; z++){
//     document.writeln(xyzArr[z]+"<br>");
// }
// for(var y = 0; y<xyzArr.length; y++){
//     document.writeln("<br>"+"Element at index "+y+" is "+xyzArr[y]+"<br>");
// }

// Question # 6

// var count = +prompt("Kahan tak counting chaheye?");
// document.writeln("Counting: ".bold()+"<br>");
// for(var c = 1; c<=count; c++){
//     document.writeln(c);
// }
// document.writeln("<br>"+"Reversed counting: ".bold()+"<br>");
// for(var r = count; r >0; r--){
//     document.writeln(r);
// }
// document.writeln("<br>"+"Even numbers: ".bold()+"<br>");
// for(var e = 0; e< c; e++){
//     if(e % 2 === 0){
//         document.writeln(" "+e+" ");
//     }
// }
// document.writeln("<br>"+"Odd numbers: ".bold()+"<br>");
// for(var o = 0; o< c; o++){
//     if(o % 2 != 0){
//         document.writeln(" "+o+" ");
//     }
// }
// document.writeln("<br>"+"Series: ".bold()+"<br>");
// for(var e = 1; e< c; e++){
//     if(e % 2 === 0){
//         document.writeln(" "+e+"k");
//     }
// }

// Question # 7

//  var Item = ["cake", "biscuit", "cookie", "chips", "patty"]
// var get = prompt("Welcome to our bakery! Please enter the item you want. :)");
// que.toLowerCase();
// var find = Item.includes(get);
// if (find == true){
//     alert("Yes "+get+ " is available");
// }
// else{
//     alert("Sorry! we dont have "+get);
// }

// Question # 8

// var LargeNum = [24, 53, 78, 91, 12];
// alert(Math.max(...LargeNum)+" is the largest number");

// Question # 9

// var SmallNum = [24, 53, 78, 91, 12];
// alert(Math.min(...SmallNum)+" is the smallest number");

// Question # 10

// document.writeln("Multiplies of 5:".bold());
// for (var x=1; x <= 100; x++){
// if( x % 5 == 0 ){
//     document.writeln(" "+x);
//     }
// }

